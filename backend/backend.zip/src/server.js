//sobe a aplicação

const app = require("./app");

app.listen(3333, () => {
    console.log("Servido rodando na porta 3333");
});