import React from "react";

import { FiGithub, FiLogOut } from "react-icons/fi";
import "./styles.css";

import fotoPerfil from "../../assets/foto_perfil.png";
import imgPost from "../../assets/post-exemplo.jpg";
import { signOut } from "../../services/security";
import { useHistory } from "react-router-dom";

function Home() {
  const history = useHistory();

  return (
    <div className="container">
      <header className="header">
        <div>
          <p>SENAI OVERFLOW</p>
        </div>
        <div>
          <input type="search" placeholder="Pesquisar uma Dúvida" />
        </div>
        <div>
          <button
            className="btnSair"
            onClick={() => {
              signOut();
              history.replace("/");
            }}
          >
            Sair <FiLogOut />
          </button>
        </div>
      </header>
      <div className="content">
        <section className="profile">
          <img src={fotoPerfil} alt="Foto de Perfil" />
          <a href="#">Editar Foto</a>
          <strong>Nome:</strong>
          <p>Fulano de tal</p>
          <strong>E-mail:</strong>
          <p>fulano@gmail.com</p>
          <strong>Ra:</strong>
          <p>1289379182</p>
        </section>
        <section className="feed">
          <div className="card-post">
            <header>
              <img src={fotoPerfil} alt="Foto de Perfil" />
              <strong>Ciclanilson</strong>
              <p> em 12/12/2012 às 12:00</p>
              <FiGithub className="icon" size={25} />
            </header>
            <body>
              <strong>Aqui é a minha pergunta</strong>
              <p>Aqui é a minha descrição da pergunta</p>
              <img src={imgPost} alt="Imagem do Post" />
            </body>
            <footer>
              <h1>Comentários</h1>
              <section>
                <header>
                  <img src={fotoPerfil} alt="Foto de Perfil" />
                  <strong>Fulanelson</strong>
                  <p> em 12/12/2012 às 13:00</p>
                </header>
                <p>Aqui é o texto do comentáriooooooo !!!!</p>
              </section>
              <section>
                <header>
                  <img src={fotoPerfil} alt="Foto de Perfil" />
                  <strong>Fulanelson</strong>
                  <p> em 12/12/2012 às 13:00</p>
                </header>
                <p>Aqui é o texto do comentáriooooooo !!!!</p>
              </section>
            </footer>
          </div>
        </section>
      </div>
    </div>
  );
}

export default Home;
